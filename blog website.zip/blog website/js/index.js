
/*  global  window $ */


$(function () {
    
    'use strict';
    
    var WinH  =  $(window).height();
        
    
    $('.slider , .carousel-item').height(WinH);
});

$(function () {
    
    'use strict';
    
    var Wdth  =  $(window).width();
        
    
    $('.home-image , img').width((Wdth * 0.5) - 15);
});

$(function () {
    
    'use strict';
    
    var WinH  =  $(window).height();
        
    
    $('.home-image').height(WinH);
});
 